# Torrent Stream (PWA + servidor)

## Arrancar
    npm install
    npm run build
    TOKEN=una-clave-larga npm start      # sirve la PWA y el streaming en :3000

## Acceso desde iPhone (HTTPS obligatorio para PWA)
La opción más simple es Tailscale en la PC/Raspberry y en el iPhone:
    tailscale serve --bg 3000
Abrí la URL https://<tu-equipo>.<tailnet>.ts.net en Safari
→ Compartir → "Añadir a pantalla de inicio" → ingresá el TOKEN.
(Alternativa: Cloudflare Tunnel.)

## Notas
- iPhone reproduce MP4/MOV/M4V (H.264/HEVC + AAC). MKV/AVI no.
- Desarrollo: `npm start` en una terminal y `npm run dev` en otra.
- Usalo solo con contenido que tengas derecho a descargar.
